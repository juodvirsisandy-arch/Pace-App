'use client'
import { Sport, SPORT_LABELS, SPORT_EMOJIS, SPORT_COLORS, SPORT_BG_COLORS } from '@/types'

interface SportBadgeProps {
  sport: Sport
  size?: 'sm' | 'md'
  showEmoji?: boolean
}

export function SportBadge({ sport, size = 'md', showEmoji = false }: SportBadgeProps) {
  const label = SPORT_LABELS[sport]
  const emoji = SPORT_EMOJIS[sport]
  const color = SPORT_COLORS[sport]
  const bg    = SPORT_BG_COLORS[sport]

  return (
    <span
      className={`inline-flex items-center gap-1 font-display font-bold tracking-wider uppercase rounded-full ${size === 'sm' ? 'text-[10px] px-2 py-0.5' : 'text-xs px-3 py-1'}`}
      style={{ color, background: bg }}
    >
      {showEmoji && <span className="text-sm">{emoji}</span>}
      {label}
    </span>
  )
}

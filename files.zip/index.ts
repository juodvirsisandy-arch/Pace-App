export type Sport = 'run' | 'bike' | 'swim' | 'triathlon' | 'ultra'

export interface Profile {
  id: string
  username: string
  full_name: string
  avatar_url?: string
  bio?: string
  location?: string
  sports: Sport[]
  created_at: string
  followers_count: number
  following_count: number
  activities_count: number
}

export interface Activity {
  id: string
  user_id: string
  sport: Sport
  title: string
  description?: string
  distance_km: number
  duration_seconds: number
  elevation_m?: number
  avg_hr?: number
  avg_pace?: number   // seconds per km for run/swim
  avg_speed?: number  // km/h for bike
  avg_power?: number  // watts
  location?: string
  route_polyline?: string
  strava_id?: string
  created_at: string
  profile?: Profile
  likes_count: number
  comments_count: number
  user_has_liked?: boolean
}

export interface Comment {
  id: string
  activity_id: string
  user_id: string
  content: string
  created_at: string
  profile?: Profile
}

export interface Follow {
  follower_id: string
  following_id: string
  created_at: string
}

export interface RaceEvent {
  id: string
  name: string
  sport: Sport
  date: string
  location: string
  country: string
  lat?: number
  lng?: number
  distance_km?: number
  description?: string
  url?: string
  going_count: number
  user_is_going?: boolean
}

export interface NearbyAthlete {
  id: string
  username: string
  full_name: string
  avatar_url?: string
  sports: Sport[]
  distance_km: number
  last_active?: string
  is_following?: boolean
}

// Sport display helpers
export const SPORT_LABELS: Record<Sport, string> = {
  run: 'Run',
  bike: 'Bike',
  swim: 'Swim',
  triathlon: 'Triathlon',
  ultra: 'Ultra',
}

export const SPORT_EMOJIS: Record<Sport, string> = {
  run: '🏃',
  bike: '🚴',
  swim: '🏊',
  triathlon: '🏅',
  ultra: '⛰️',
}

export const SPORT_COLORS: Record<Sport, string> = {
  run: '#FF6B35',
  bike: '#3B82F6',
  swim: '#06B6D4',
  triathlon: '#8B5CF6',
  ultra: '#22c55e',
}

export const SPORT_BG_COLORS: Record<Sport, string> = {
  run: '#FF6B3518',
  bike: '#3B82F618',
  swim: '#06B6D418',
  triathlon: '#8B5CF618',
  ultra: '#22c55e18',
}

// Formatting helpers
export function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
  return `${m}:${String(s).padStart(2, '0')}`
}

export function formatPace(secondsPerKm: number): string {
  const m = Math.floor(secondsPerKm / 60)
  const s = secondsPerKm % 60
  return `${m}:${String(s).padStart(2, '0')}`
}

export function formatDistance(km: number): string {
  if (km >= 100) return `${Math.round(km)} km`
  return `${km.toFixed(1)} km`
}

'use client'
import { useState } from 'react'
import { Heart, MessageCircle, Share2, MapPin } from 'lucide-react'
import { Activity, formatDuration, formatDistance, formatPace, SPORT_EMOJIS } from '@/types'
import { Avatar } from '@/components/ui/Avatar'
import { SportBadge } from '@/components/ui/SportBadge'
import { StatChip } from '@/components/ui/StatChip'
import { formatDistanceToNow } from 'date-fns'

interface ActivityCardProps {
  activity: Activity
}

export function ActivityCard({ activity }: ActivityCardProps) {
  const [liked, setLiked] = useState(activity.user_has_liked || false)
  const [likes, setLikes] = useState(activity.likes_count)
  const profile = activity.profile

  function toggleLike() {
    setLiked(l => !l)
    setLikes(n => liked ? n - 1 : n + 1)
  }

  function getStats() {
    const stats: { value: string; label: string; unit?: string }[] = []

    stats.push({ value: formatDistance(activity.distance_km).replace(' km', ''), label: 'Distance', unit: 'km' })
    stats.push({ value: formatDuration(activity.duration_seconds), label: activity.sport === 'bike' ? 'Moving time' : 'Time' })

    if (activity.avg_pace && (activity.sport === 'run' || activity.sport === 'ultra')) {
      stats.push({ value: formatPace(activity.avg_pace), label: 'Pace /km' })
    } else if (activity.avg_pace && activity.sport === 'swim') {
      stats.push({ value: formatPace(activity.avg_pace), label: '/100m' })
    } else if (activity.avg_speed && activity.sport === 'bike') {
      stats.push({ value: activity.avg_speed.toFixed(1), label: 'km/h' })
    }

    if (activity.elevation_m) {
      stats.push({ value: activity.elevation_m.toString(), label: 'Elev m' })
    } else if (activity.avg_hr) {
      stats.push({ value: activity.avg_hr.toString(), label: 'Avg HR' })
    } else if (activity.avg_power) {
      stats.push({ value: activity.avg_power.toString(), label: 'Avg W' })
    }

    return stats.slice(0, 4)
  }

  return (
    <article className="card overflow-hidden animate-fade-up">

      {/* Header */}
      <div className="flex items-center gap-3 p-4 pb-3">
        <Avatar name={profile?.full_name || 'Athlete'} src={profile?.avatar_url} size={42} />
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-pace-ink truncate">{profile?.full_name}</div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="font-mono-pace text-[11px] text-pace-ink3">
              {formatDistanceToNow(new Date(activity.created_at), { addSuffix: true })}
            </span>
            {activity.location && (
              <>
                <span className="text-pace-border">·</span>
                <MapPin size={11} className="text-pace-ink3 flex-shrink-0" />
                <span className="font-mono-pace text-[11px] text-pace-ink3 truncate">{activity.location}</span>
              </>
            )}
          </div>
        </div>
        <SportBadge sport={activity.sport} />
      </div>

      {/* Route map placeholder — will be real Mapbox later */}
      <div className="mx-4 mb-3 h-20 rounded-xl overflow-hidden bg-pace-surface2 relative">
        <svg viewBox="0 0 400 80" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
          <rect width="400" height="80" fill="#ECEAE3"/>
          <path d="M10 50 Q60 20 110 42 Q155 58 200 30 Q245 8 285 34 Q320 52 390 28"
            stroke="#D0CFC8" strokeWidth="1" fill="none"/>
          <path d="M10 60 Q70 38 130 55 Q175 66 220 44 Q265 30 310 50 Q345 62 390 50"
            stroke="#D0CFC8" strokeWidth="1" fill="none"/>
          <path
            d={`M20 55 Q80 ${activity.sport === 'bike' ? '15' : '28'} 140 45 Q185 55 240 28 Q280 ${activity.sport === 'run' ? '10' : '18'} 330 38 Q360 46 390 30`}
            stroke={activity.sport === 'triathlon' ? '#8B5CF6' : activity.sport === 'run' ? '#FF6B35' : activity.sport === 'bike' ? '#3B82F6' : '#06B6D4'}
            strokeWidth="2.5" fill="none" strokeLinecap="round"
          />
          <circle cx="20" cy="55" r="5" fill={activity.sport === 'run' ? '#FF6B35' : activity.sport === 'bike' ? '#3B82F6' : activity.sport === 'swim' ? '#06B6D4' : '#8B5CF6'}/>
          <circle cx="390" cy="30" r="5" fill="#E8FF47" stroke="#0F0F0E" strokeWidth="1.5"/>
        </svg>
        <div className="absolute top-2 right-2 bg-white/80 backdrop-blur-sm rounded-full px-2 py-0.5 font-mono-pace text-[10px] text-pace-ink2">
          {SPORT_EMOJIS[activity.sport]} {activity.sport.toUpperCase()}
        </div>
      </div>

      {/* Stats */}
      <div className="flex gap-5 px-4 pb-3">
        {getStats().map((s, i) => (
          <StatChip key={i} value={s.value} label={s.label} unit={s.unit} />
        ))}
      </div>

      {/* Title + description */}
      <div className="px-4 pb-3">
        <div className="font-display font-bold text-lg text-pace-ink leading-tight mb-1">
          {activity.title}
        </div>
        {activity.description && (
          <p className="text-sm text-pace-ink2 leading-relaxed">{activity.description}</p>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-4 px-4 py-3 border-t border-pace-border">
        <button
          onClick={toggleLike}
          className="flex items-center gap-1.5 font-mono-pace text-xs transition-colors"
          style={{ color: liked ? '#FF6B35' : '#9A9A94' }}
        >
          <Heart size={16} fill={liked ? '#FF6B35' : 'none'} />
          {likes}
        </button>
        <button className="flex items-center gap-1.5 font-mono-pace text-xs text-pace-ink3 hover:text-pace-ink transition-colors">
          <MessageCircle size={16} />
          {activity.comments_count}
        </button>
        <button className="flex items-center gap-1.5 font-mono-pace text-xs text-pace-ink3 hover:text-pace-ink transition-colors ml-auto">
          <Share2 size={16} />
          Share
        </button>
      </div>
    </article>
  )
}

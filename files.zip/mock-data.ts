import { Activity, Profile, RaceEvent, NearbyAthlete } from '@/types'

export const MOCK_PROFILES: Profile[] = [
  {
    id: '1', username: 'anna_tri', full_name: 'Anna Vestergaard',
    bio: 'Full IRONMAN finisher. Chasing Kona. 🏝️', location: 'Copenhagen, DK',
    sports: ['triathlon', 'swim', 'run'], created_at: '2024-01-01',
    followers_count: 1420, following_count: 248, activities_count: 312,
  },
  {
    id: '2', username: 'marco_run', full_name: 'Marco Trevisan',
    bio: 'Running for pasta 🍝. Sub-3h marathon target 2025.', location: 'Milan, IT',
    sports: ['run', 'triathlon'], created_at: '2024-02-01',
    followers_count: 834, following_count: 190, activities_count: 187,
  },
  {
    id: '3', username: 'kai_swim', full_name: 'Kai Nakamura',
    bio: 'Open water swimmer. 5k OW PR: 1:24. Pacific vibes 🌊', location: 'Tokyo, JP',
    sports: ['swim', 'triathlon'], created_at: '2024-01-15',
    followers_count: 612, following_count: 155, activities_count: 203,
  },
  {
    id: '4', username: 'sophie_bike', full_name: 'Sophie Renard',
    bio: 'Cyclist & gravel enthusiast. Alps > everything.', location: 'Lyon, FR',
    sports: ['bike'], created_at: '2024-03-01',
    followers_count: 445, following_count: 120, activities_count: 98,
  },
]

export const MOCK_ACTIVITIES: Activity[] = [
  {
    id: 'a1', user_id: '1', sport: 'triathlon',
    title: 'IRONMAN Copenhagen — Done! 🏅',
    description: 'Finally finished my first full IRONMAN 🙌 Months of early mornings paid off. The run felt impossible after the bike but here we are. Thank you everyone for the support!',
    distance_km: 226, duration_seconds: 42120, elevation_m: 847,
    avg_hr: 158, location: 'Copenhagen, DK',
    created_at: new Date(Date.now() - 2 * 3600000).toISOString(),
    profile: MOCK_PROFILES[0],
    likes_count: 247, comments_count: 38, user_has_liked: false,
  },
  {
    id: 'a2', user_id: '2', sport: 'run',
    title: 'Half Marathon PR! 🎯',
    description: 'Shaved 4 minutes off my PB. The new interval sessions are working. Who else is training for Barcelona?',
    distance_km: 21.1, duration_seconds: 5880, avg_hr: 164,
    avg_pace: 279, location: 'Milan, IT',
    created_at: new Date(Date.now() - 5 * 3600000).toISOString(),
    profile: MOCK_PROFILES[1],
    likes_count: 183, comments_count: 21, user_has_liked: true,
  },
  {
    id: 'a3', user_id: '3', sport: 'swim',
    title: 'Open Water 5k ✅',
    description: 'Visibility was amazing today. Next up: qualifying swim for Kona. Anyone training in the Pacific region?',
    distance_km: 5, duration_seconds: 5280, avg_pace: 105,
    location: 'Tokyo Bay, JP',
    created_at: new Date(Date.now() - 22 * 3600000).toISOString(),
    profile: MOCK_PROFILES[2],
    likes_count: 94, comments_count: 14, user_has_liked: false,
  },
  {
    id: 'a4', user_id: '4', sport: 'bike',
    title: 'Col du Galibier — 2645m summit 🏔️',
    description: '120km with 3200m elevation. Legs are gone but the views were worth every pedal stroke.',
    distance_km: 120, duration_seconds: 14400, elevation_m: 3200,
    avg_speed: 28.5, avg_power: 218, location: 'Alps, FR',
    created_at: new Date(Date.now() - 30 * 3600000).toISOString(),
    profile: MOCK_PROFILES[3],
    likes_count: 156, comments_count: 27, user_has_liked: false,
  },
]

export const MOCK_EVENTS: RaceEvent[] = [
  {
    id: 'e1', name: 'IRONMAN Copenhagen', sport: 'triathlon',
    date: '2025-08-18', location: 'Copenhagen', country: 'DK',
    distance_km: 226, going_count: 841, user_is_going: true,
    description: 'The flagship Scandinavian full distance triathlon.',
    lat: 55.6761, lng: 12.5683,
  },
  {
    id: 'e2', name: 'Euro Open Water Championships', sport: 'swim',
    date: '2025-09-06', location: 'Zürich', country: 'CH',
    distance_km: 10, going_count: 312, user_is_going: false,
    lat: 47.3769, lng: 8.5417,
  },
  {
    id: 'e3', name: 'Barcelona Marathon', sport: 'run',
    date: '2025-10-12', location: 'Barcelona', country: 'ES',
    distance_km: 42.2, going_count: 2104, user_is_going: false,
    lat: 41.3851, lng: 2.1734,
  },
  {
    id: 'e4', name: "Alpe d'Huez Gran Fondo", sport: 'bike',
    date: '2025-07-05', location: "Alpe d'Huez", country: 'FR',
    distance_km: 140, going_count: 567, user_is_going: false,
    lat: 45.0922, lng: 6.0706,
  },
  {
    id: 'e5', name: 'IRONMAN 70.3 Gdynia', sport: 'triathlon',
    date: '2025-06-22', location: 'Gdynia', country: 'PL',
    distance_km: 113, going_count: 480, user_is_going: false,
    lat: 54.5189, lng: 18.5305,
  },
  {
    id: 'e6', name: 'Vilnius Trail Ultra 108k', sport: 'ultra',
    date: '2025-05-08', location: 'Vilnius', country: 'LT',
    distance_km: 108, going_count: 203, user_is_going: true,
    lat: 54.6872, lng: 25.2797,
  },
]

export const MOCK_NEARBY: NearbyAthlete[] = [
  { id: '2', username: 'marco_run', full_name: 'Marco Trevisan', sports: ['run', 'triathlon'], distance_km: 1.2, is_following: false },
  { id: '4', username: 'sophie_bike', full_name: 'Sophie Renard', sports: ['bike'], distance_km: 3.8, is_following: true },
  { id: '1', username: 'anna_tri', full_name: 'Anna Vestergaard', sports: ['triathlon', 'swim'], distance_km: 4.1, is_following: false },
  { id: '5', username: 'jan_ultra', full_name: 'Jan Kowalski', sports: ['run', 'ultra'], distance_km: 7.5, is_following: false },
  { id: '6', username: 'lena_swim', full_name: 'Lena Müller', sports: ['swim', 'triathlon'], distance_km: 9.1, is_following: false },
]

export const MY_PROFILE: Profile = {
  id: 'me', username: 'your_handle', full_name: 'You',
  bio: 'Triathlete · Marathon runner · Always chasing the next finish line 🏁',
  location: 'Vilnius, LT',
  sports: ['triathlon', 'run', 'swim'],
  created_at: '2024-01-01',
  followers_count: 1400, following_count: 248, activities_count: 87,
}

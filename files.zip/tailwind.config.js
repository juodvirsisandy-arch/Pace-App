/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        pace: {
          bg:      '#F5F4F0',
          surface: '#FFFFFF',
          surface2:'#EEEDE9',
          ink:     '#0F0F0E',
          ink2:    '#5A5A56',
          ink3:    '#9A9A94',
          border:  '#E2E1DC',
          accent:  '#E8FF47',
          run:     '#FF6B35',
          bike:    '#3B82F6',
          swim:    '#06B6D4',
          tri:     '#8B5CF6',
        }
      },
      fontFamily: {
        display: ['"Barlow Condensed"', 'sans-serif'],
        body:    ['"DM Sans"', 'sans-serif'],
        mono:    ['"DM Mono"', 'monospace'],
      },
      borderRadius: {
        'xl': '14px',
        '2xl': '20px',
        '3xl': '28px',
      },
      animation: {
        'fade-up': 'fadeUp 0.4s ease both',
        'pulse-dot': 'pulseDot 2s ease-in-out infinite',
      },
      keyframes: {
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(12px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        pulseDot: {
          '0%,100%': { transform: 'scale(1)', opacity: '1' },
          '50%':     { transform: 'scale(1.5)', opacity: '0.4' },
        }
      }
    },
  },
  plugins: [],
}

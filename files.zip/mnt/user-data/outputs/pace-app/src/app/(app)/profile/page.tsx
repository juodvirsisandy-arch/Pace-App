'use client'
import { useState } from 'react'
import { MapPin, Settings, Award, TrendingUp } from 'lucide-react'
import { Avatar } from '@/components/ui/Avatar'
import { SportBadge } from '@/components/ui/SportBadge'
import { ActivityCard } from '@/components/feed/ActivityCard'
import { MY_PROFILE, MOCK_ACTIVITIES } from '@/lib/mock-data'
import { Sport, SPORT_EMOJIS, formatDistance, formatDuration, formatPace } from '@/types'

const YEAR_STATS = [
  { sport: 'run'  as Sport, distance: 412,  label: 'km run',  color: '#FF6B35' },
  { sport: 'bike' as Sport, distance: 1840, label: 'km bike', color: '#3B82F6' },
  { sport: 'swim' as Sport, distance: 68,   label: 'km swim', color: '#06B6D4' },
]

const RECENT = [
  { sport: 'run'  as Sport, title: 'Morning Run',   date: 'Today · 6:14 AM',      dist: 12.4, pace: 292, hr: 148 },
  { sport: 'bike' as Sport, title: 'Long Ride',      date: 'Yesterday · 7:00 AM',  dist: 94,   speed: 32.1 },
  { sport: 'swim' as Sport, title: 'Pool Session',   date: 'Mon · 5:45 AM',        dist: 3.8,  pace: 112 },
  { sport: 'tri'  as Sport, title: 'Brick Session',  date: 'Sun · 8:00 AM',        dist: 52,   label: 'Bike + Run' },
]

const BADGES = [
  { label: 'IRONMAN 70.3',   sport: 'triathlon' as Sport },
  { label: 'SUB-2:45 MARA', sport: 'run'       as Sport },
  { label: 'OW 5K',         sport: 'swim'      as Sport },
]

export default function ProfilePage() {
  const [tab, setTab] = useState<'activities' | 'stats'>('activities')
  const myActivities = MOCK_ACTIVITIES.slice(0, 2)

  return (
    <div className="max-w-2xl mx-auto pb-6">
      {/* Hero */}
      <div className="bg-pace-ink px-4 pt-6 pb-0 relative">
        {/* Settings button */}
        <button className="absolute top-5 right-4 w-9 h-9 flex items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 transition-colors">
          <Settings size={17} className="text-white" />
        </button>

        {/* Profile info */}
        <div className="flex gap-4 mb-4">
          <div className="relative">
            <Avatar name={MY_PROFILE.full_name} size={80} />
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-pace-accent rounded-full flex items-center justify-center text-xs font-bold text-pace-ink border-2 border-pace-ink">
              ✓
            </div>
          </div>
          <div className="pt-1 flex-1 min-w-0">
            <h1 className="font-display font-black text-3xl text-white leading-none">{MY_PROFILE.full_name}</h1>
            <div className="font-mono-pace text-xs text-white/40 mt-1">@{MY_PROFILE.username}</div>
            <div className="flex items-center gap-1.5 mt-1.5">
              <MapPin size={11} className="text-white/40" />
              <span className="font-mono-pace text-xs text-white/40">{MY_PROFILE.location}</span>
            </div>
          </div>
        </div>

        {/* Bio */}
        {MY_PROFILE.bio && (
          <p className="text-sm text-white/60 leading-relaxed mb-4">{MY_PROFILE.bio}</p>
        )}

        {/* Sport badges */}
        <div className="flex flex-wrap gap-2 mb-4">
          {MY_PROFILE.sports.map(s => (
            <SportBadge key={s} sport={s} showEmoji />
          ))}
        </div>

        {/* Achievement badges */}
        <div className="flex flex-wrap gap-2 mb-5">
          {BADGES.map(b => (
            <span
              key={b.label}
              className="flex items-center gap-1.5 font-mono-pace text-[10px] font-bold px-2.5 py-1 rounded-lg"
              style={{ background: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.6)' }}
            >
              <Award size={11} />
              {b.label}
            </span>
          ))}
        </div>

        {/* Stats bar */}
        <div className="flex border-t border-white/10 -mx-4 px-4">
          {[
            { val: MY_PROFILE.following_count,  lbl: 'Following'  },
            { val: `${(MY_PROFILE.followers_count / 1000).toFixed(1)}K`, lbl: 'Followers' },
            { val: MY_PROFILE.activities_count, lbl: 'Activities' },
            { val: 3,                            lbl: 'Races 2025' },
          ].map((s, i, arr) => (
            <div key={s.lbl} className={`flex-1 text-center py-4 ${i < arr.length - 1 ? 'border-r border-white/10' : ''}`}>
              <div className="font-display font-black text-2xl text-pace-accent leading-none">{s.val}</div>
              <div className="font-mono-pace text-[10px] text-white/40 mt-1 uppercase tracking-wider">{s.lbl}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-pace-border bg-pace-surface sticky top-0 z-30">
        {(['activities', 'stats'] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-3.5 font-mono-pace text-xs uppercase tracking-widest transition-colors ${
              tab === t ? 'text-pace-ink border-b-2 border-pace-ink' : 'text-pace-ink3 hover:text-pace-ink2'
            }`}
          >
            {t === 'activities' ? 'Activities' : '2025 Stats'}
          </button>
        ))}
      </div>

      {tab === 'activities' ? (
        <div className="px-4 pt-4 flex flex-col gap-3">
          {myActivities.map(a => <ActivityCard key={a.id} activity={{ ...a, profile: { ...MY_PROFILE, id: 'me', sports: MY_PROFILE.sports } }} />)}
        </div>
      ) : (
        <div className="px-4 pt-4">
          {/* Year totals */}
          <div className="font-mono-pace text-[10px] text-pace-ink3 uppercase tracking-widest mb-3">2025 Totals</div>
          <div className="grid grid-cols-3 gap-3 mb-6">
            {YEAR_STATS.map(s => (
              <div key={s.sport} className="card p-3.5 text-center">
                <div className="text-2xl mb-1">{SPORT_EMOJIS[s.sport]}</div>
                <div className="font-display font-bold text-2xl leading-none" style={{ color: s.color }}>
                  {s.distance.toLocaleString()}
                </div>
                <div className="font-mono-pace text-[10px] text-pace-ink3 mt-1">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Recent activities */}
          <div className="font-mono-pace text-[10px] text-pace-ink3 uppercase tracking-widest mb-3">Recent activities</div>
          <div className="flex flex-col gap-2.5">
            {RECENT.map((r, i) => (
              <div key={i} className="card p-3.5 flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                  style={{ background: r.sport === 'run' ? '#FF6B3515' : r.sport === 'bike' ? '#3B82F615' : r.sport === 'swim' ? '#06B6D415' : '#8B5CF615' }}
                >
                  {SPORT_EMOJIS[r.sport as Sport] || '🏅'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm text-pace-ink truncate">{r.title}</div>
                  <div className="font-mono-pace text-[11px] text-pace-ink3 mt-0.5">{r.date}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="font-display font-bold text-lg text-pace-ink leading-none">
                    {r.dist} <span className="font-body font-normal text-xs text-pace-ink3">km</span>
                  </div>
                  <div className="font-mono-pace text-[11px] text-pace-ink3 mt-0.5">
                    {r.pace ? `${formatPace(r.pace)}/km` : r.speed ? `${r.speed} km/h` : r.label || ''}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

'use client'
import { useState } from 'react'
import { Calendar, MapPin, Users, ExternalLink, Check } from 'lucide-react'
import { SportBadge } from '@/components/ui/SportBadge'
import { Avatar } from '@/components/ui/Avatar'
import { MOCK_EVENTS, MOCK_PROFILES } from '@/lib/mock-data'
import { RaceEvent, Sport, SPORT_COLORS } from '@/types'
import { format, parseISO, isPast } from 'date-fns'

const FILTERS: { label: string; value: Sport | 'all' | 'going' }[] = [
  { label: 'All events', value: 'all' },
  { label: '✓ Going', value: 'going' },
  { label: '🏅 Triathlon', value: 'triathlon' },
  { label: '🏃 Running', value: 'run' },
  { label: '🚴 Cycling', value: 'bike' },
  { label: '🏊 Open water', value: 'swim' },
  { label: '⛰️ Ultra', value: 'ultra' },
]

const BANNER_PATTERNS: Record<string, string> = {
  triathlon: 'linear-gradient(135deg, #1a1a40 0%, #3B2472 100%)',
  run:       'linear-gradient(135deg, #1a1212 0%, #5c1a00 100%)',
  bike:      'linear-gradient(135deg, #0a1a10 0%, #1a4a28 100%)',
  swim:      'linear-gradient(135deg, #0c2340 0%, #1a5276 100%)',
  ultra:     'linear-gradient(135deg, #0f1a0a 0%, #2d4a1a 100%)',
}

function EventCard({ event, onToggle }: { event: RaceEvent; onToggle: (id: string) => void }) {
  const date = parseISO(event.date)
  const past = isPast(date)
  const goingProfiles = MOCK_PROFILES.slice(0, Math.min(3, Math.floor(event.going_count / 250) + 1))

  return (
    <article className="card overflow-hidden animate-fade-up">
      {/* Banner */}
      <div
        className="h-24 flex items-end p-3 relative overflow-hidden"
        style={{ background: BANNER_PATTERNS[event.sport] || BANNER_PATTERNS.run }}
      >
        {/* subtle pattern */}
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 400 96" preserveAspectRatio="xMidYMid slice">
          <circle cx="350" cy="20" r="80" fill="white"/>
          <circle cx="40" cy="90" r="50" fill="white"/>
        </svg>
        <div className="relative z-10 flex items-center justify-between w-full">
          <SportBadge sport={event.sport} showEmoji />
          {event.distance_km && (
            <span className="font-display font-bold text-white/80 text-lg">
              {event.distance_km}km
            </span>
          )}
        </div>
      </div>

      {/* Body */}
      <div className="p-4">
        <h3 className="font-display font-bold text-xl text-pace-ink leading-tight">{event.name}</h3>

        <div className="flex flex-wrap gap-x-4 gap-y-1.5 mt-2.5">
          <div className="flex items-center gap-1.5 font-mono-pace text-xs text-pace-ink3">
            <Calendar size={12} />
            {format(date, 'MMM d, yyyy')}
            {past && <span className="text-pace-run">(past)</span>}
          </div>
          <div className="flex items-center gap-1.5 font-mono-pace text-xs text-pace-ink3">
            <MapPin size={12} />
            {event.location}, {event.country}
          </div>
        </div>

        {event.description && (
          <p className="text-sm text-pace-ink3 mt-2 leading-relaxed">{event.description}</p>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-pace-border">
          <div className="flex items-center gap-2">
            {/* Going avatars */}
            <div className="flex">
              {goingProfiles.map((p, i) => (
                <div key={p.id} style={{ marginLeft: i === 0 ? 0 : -8, zIndex: goingProfiles.length - i }}>
                  <Avatar name={p.full_name} size={24} className="border-2 border-white" />
                </div>
              ))}
            </div>
            <span className="font-mono-pace text-xs text-pace-ink3">
              +{event.going_count.toLocaleString()} going
            </span>
          </div>

          <button
            onClick={() => onToggle(event.id)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold font-mono-pace transition-all ${
              event.user_is_going
                ? 'bg-pace-surface2 text-pace-ink2'
                : 'bg-pace-ink text-pace-accent hover:opacity-90 active:scale-95'
            }`}
          >
            {event.user_is_going ? <><Check size={13} /> Joined</> : 'Join'}
          </button>
        </div>
      </div>
    </article>
  )
}

export default function EventsPage() {
  const [filter, setFilter] = useState<Sport | 'all' | 'going'>('all')
  const [events, setEvents] = useState(MOCK_EVENTS)

  const filtered = events.filter(e => {
    if (filter === 'all') return true
    if (filter === 'going') return e.user_is_going
    return e.sport === filter
  })

  function handleToggle(id: string) {
    setEvents(prev => prev.map(e =>
      e.id === id ? { ...e, user_is_going: !e.user_is_going, going_count: e.user_is_going ? e.going_count - 1 : e.going_count + 1 } : e
    ))
  }

  const goingCount = events.filter(e => e.user_is_going).length

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="px-4 pt-6 pb-4">
        <h1 className="font-display font-black text-4xl text-pace-ink leading-none tracking-wide">
          RACE<br />BOARD
        </h1>
        <div className="flex items-center gap-3 mt-2">
          <span className="font-mono-pace text-xs text-pace-ink3">Upcoming events worldwide</span>
          {goingCount > 0 && (
            <span className="bg-pace-accent text-pace-ink font-mono-pace text-[10px] font-bold px-2 py-0.5 rounded-full">
              {goingCount} joined
            </span>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 px-4 pb-4 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
        {FILTERS.map(f => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-full font-mono-pace text-xs font-medium transition-all ${
              filter === f.value
                ? 'bg-pace-ink text-pace-accent'
                : 'bg-pace-surface border border-pace-border text-pace-ink2 hover:border-pace-ink3'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Events list */}
      <div className="px-4 flex flex-col gap-3 pb-6">
        {filtered.length === 0 ? (
          <div className="text-center py-16 text-pace-ink3 font-mono-pace text-sm">
            No events found
          </div>
        ) : (
          filtered.map((event, i) => (
            <div key={event.id} style={{ animationDelay: `${i * 0.07}s` }}>
              <EventCard event={event} onToggle={handleToggle} />
            </div>
          ))
        )}
      </div>
    </div>
  )
}

'use client'
import { useState } from 'react'
import { MapPin, UserPlus, Check } from 'lucide-react'
import { Avatar } from '@/components/ui/Avatar'
import { SportBadge } from '@/components/ui/SportBadge'
import { MOCK_NEARBY } from '@/lib/mock-data'
import { Sport, SPORT_EMOJIS, SPORT_COLORS, NearbyAthlete } from '@/types'

const FILTERS: { label: string; value: Sport | 'all' }[] = [
  { label: 'All sports', value: 'all' },
  { label: '🏃 Runners', value: 'run' },
  { label: '🚴 Cyclists', value: 'bike' },
  { label: '🏊 Swimmers', value: 'swim' },
  { label: '🏅 Triathletes', value: 'triathlon' },
  { label: '⛰️ Ultra', value: 'ultra' },
]

// Fake map pins for the SVG map
const MAP_PINS = [
  { x: 80,  y: 62,  name: 'Marco Trevisan',   sport: 'run' as Sport,       initials: 'MT' },
  { x: 245, y: 72,  name: 'Sophie Renard',     sport: 'bike' as Sport,      initials: 'SR' },
  { x: 155, y: 148, name: 'Anna Vestergaard',  sport: 'triathlon' as Sport, initials: 'AV' },
  { x: 300, y: 55,  name: 'Kai Nakamura',      sport: 'swim' as Sport,      initials: 'KN' },
  { x: 55,  y: 142, name: 'Jan Kowalski',      sport: 'run' as Sport,       initials: 'JK' },
  { x: 320, y: 130, name: 'Lena Müller',       sport: 'swim' as Sport,      initials: 'LM' },
]

function MapView({ filter }: { filter: Sport | 'all' }) {
  const pins = filter === 'all' ? MAP_PINS : MAP_PINS.filter(p => p.sport === filter)

  return (
    <div className="mx-4 mb-4 rounded-2xl overflow-hidden border border-pace-border bg-pace-surface2" style={{ height: 220 }}>
      <svg viewBox="0 0 380 220" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
        {/* Background */}
        <rect width="380" height="220" fill="#E8E7E0"/>
        {/* Grid roads */}
        <line x1="0" y1="88" x2="380" y2="88" stroke="#D4D3CC" strokeWidth="9"/>
        <line x1="0" y1="148" x2="380" y2="148" stroke="#D4D3CC" strokeWidth="6"/>
        <line x1="0" y1="55"  x2="380" y2="55"  stroke="#D4D3CC" strokeWidth="4"/>
        <line x1="0" y1="178" x2="380" y2="178" stroke="#D4D3CC" strokeWidth="3"/>
        <line x1="120" y1="0" x2="120" y2="220" stroke="#D4D3CC" strokeWidth="9"/>
        <line x1="240" y1="0" x2="240" y2="220" stroke="#D4D3CC" strokeWidth="6"/>
        <line x1="60"  y1="0" x2="60"  y2="220" stroke="#D4D3CC" strokeWidth="4"/>
        <line x1="310" y1="0" x2="310" y2="220" stroke="#D4D3CC" strokeWidth="3"/>
        {/* Park */}
        <rect x="140" y="98" width="90" height="42" rx="5" fill="#D4EDCA" opacity="0.8"/>
        <text x="155" y="124" fontSize="9" fontFamily="monospace" fill="#6AAB5A" opacity="0.8">PARK</text>
        {/* Water */}
        <ellipse cx="338" cy="168" rx="40" ry="26" fill="#BDE4EE" opacity="0.75"/>
        {/* Road center lines */}
        <line x1="0" y1="88" x2="380" y2="88" stroke="white" strokeWidth="1.5" strokeDasharray="22,16" opacity="0.6"/>
        <line x1="120" y1="0" x2="120" y2="220" stroke="white" strokeWidth="1.5" strokeDasharray="22,16" opacity="0.6"/>

        {/* You dot */}
        <circle cx="190" cy="110" r="16" fill="#0F0F0E" opacity="0.12"/>
        <circle cx="190" cy="110" r="10" fill="#E8FF47" stroke="#0F0F0E" strokeWidth="2.5"/>
        <text x="177" y="130" fontSize="8" fontFamily="monospace" fill="#0F0F0E" fontWeight="bold">YOU</text>

        {/* Athlete pins */}
        {pins.map((pin, i) => (
          <g key={i} style={{ animation: `pulseDot ${1.8 + i * 0.3}s ease-in-out infinite` }}>
            <circle cx={pin.x} cy={pin.y} r="14" fill={SPORT_COLORS[pin.sport]} opacity="0.18"/>
            <circle cx={pin.x} cy={pin.y} r="8" fill={SPORT_COLORS[pin.sport]}/>
            <text x={pin.x - 5} y={pin.y + 3} fontSize="7" fill="white" fontWeight="bold">{pin.initials[0]}</text>
          </g>
        ))}
      </svg>
    </div>
  )
}

function AthleteRow({ athlete, onConnect }: { athlete: NearbyAthlete; onConnect: (id: string) => void }) {
  return (
    <div className="card p-3.5 flex items-center gap-3">
      <Avatar name={athlete.full_name} src={athlete.avatar_url} size={48} />
      <div className="flex-1 min-w-0">
        <div className="font-semibold text-pace-ink truncate">{athlete.full_name}</div>
        <div className="flex flex-wrap gap-1.5 mt-1.5">
          {athlete.sports.map(s => (
            <SportBadge key={s} sport={s} size="sm" showEmoji />
          ))}
        </div>
      </div>
      <div className="flex flex-col items-end gap-2 flex-shrink-0">
        <div className="font-display font-bold text-lg text-pace-ink2 leading-none">
          {athlete.distance_km.toFixed(1)}
          <span className="font-body font-normal text-xs text-pace-ink3 ml-0.5">km</span>
        </div>
        <button
          onClick={() => onConnect(athlete.id)}
          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold font-mono-pace transition-all ${
            athlete.is_following
              ? 'bg-pace-surface2 text-pace-ink2'
              : 'bg-pace-ink text-pace-accent hover:opacity-90'
          }`}
        >
          {athlete.is_following ? <><Check size={12} /> Following</> : <><UserPlus size={12} /> Connect</>}
        </button>
      </div>
    </div>
  )
}

export default function NearbyPage() {
  const [filter, setFilter] = useState<Sport | 'all'>('all')
  const [athletes, setAthletes] = useState(MOCK_NEARBY)

  const filtered = filter === 'all' ? athletes : athletes.filter(a => a.sports.includes(filter))

  function handleConnect(id: string) {
    setAthletes(prev => prev.map(a =>
      a.id === id ? { ...a, is_following: !a.is_following } : a
    ))
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="px-4 pt-6 pb-4">
        <h1 className="font-display font-black text-4xl text-pace-ink leading-none tracking-wide">
          NEARBY<br />ATHLETES
        </h1>
        <div className="flex items-center gap-1.5 mt-2">
          <MapPin size={13} className="text-pace-ink3" />
          <span className="font-mono-pace text-xs text-pace-ink3">
            {filtered.length} athletes within 10km · Vilnius, LT
          </span>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 px-4 pb-4 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
        {FILTERS.map(f => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-full font-mono-pace text-xs font-medium transition-all ${
              filter === f.value
                ? 'bg-pace-ink text-pace-accent'
                : 'bg-pace-surface border border-pace-border text-pace-ink2 hover:border-pace-ink3'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Map */}
      <MapView filter={filter} />

      {/* List */}
      <div className="px-4 flex flex-col gap-2.5 pb-6">
        <div className="font-mono-pace text-[10px] text-pace-ink3 uppercase tracking-widest mb-1">
          Athletes near you
        </div>
        {filtered.map(athlete => (
          <AthleteRow key={athlete.id} athlete={athlete} onConnect={handleConnect} />
        ))}
      </div>
    </div>
  )
}

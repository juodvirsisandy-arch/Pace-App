'use client'
import { useState } from 'react'
import { Bell, Search, Plus } from 'lucide-react'
import { ActivityCard } from '@/components/feed/ActivityCard'
import { StoriesRow } from '@/components/feed/StoriesRow'
import { MOCK_ACTIVITIES, MOCK_PROFILES } from '@/lib/mock-data'
import { Sport } from '@/types'

const FILTERS: { label: string; value: Sport | 'all' }[] = [
  { label: 'All', value: 'all' },
  { label: '🏃 Run', value: 'run' },
  { label: '🚴 Bike', value: 'bike' },
  { label: '🏊 Swim', value: 'swim' },
  { label: '🏅 Tri', value: 'triathlon' },
  { label: '⛰️ Ultra', value: 'ultra' },
]

export default function FeedPage() {
  const [filter, setFilter] = useState<Sport | 'all'>('all')

  const activities = filter === 'all'
    ? MOCK_ACTIVITIES
    : MOCK_ACTIVITIES.filter(a => a.sport === filter)

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-pace-bg/90 backdrop-blur-md border-b border-pace-border">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="lg:hidden font-display font-black text-3xl">
            <span className="bg-pace-ink text-pace-accent px-1.5 py-0.5 rounded">PACE</span>
          </div>
          <h1 className="hidden lg:block font-display font-black text-3xl text-pace-ink tracking-wide">
            Feed
          </h1>
          <div className="flex items-center gap-2">
            <button className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-pace-surface2 transition-colors relative">
              <Search size={18} className="text-pace-ink2" />
            </button>
            <button className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-pace-surface2 transition-colors relative">
              <Bell size={18} className="text-pace-ink2" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-pace-run rounded-full" />
            </button>
          </div>
        </div>

        {/* Sport filters */}
        <div className="flex gap-2 px-4 pb-3 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
          {FILTERS.map(f => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-full font-mono-pace text-xs font-medium transition-all ${
                filter === f.value
                  ? 'bg-pace-ink text-pace-accent'
                  : 'bg-pace-surface border border-pace-border text-pace-ink2 hover:border-pace-ink3'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Stories */}
      <div className="pt-4">
        <StoriesRow athletes={MOCK_PROFILES} />
      </div>

      <div className="h-px bg-pace-border mx-4 mb-4" />

      {/* Feed */}
      <div className="px-4 flex flex-col gap-3 pb-6">
        {activities.length === 0 ? (
          <div className="text-center py-16 text-pace-ink3 font-mono-pace text-sm">
            No {filter} activities yet
          </div>
        ) : (
          activities.map((activity, i) => (
            <div key={activity.id} style={{ animationDelay: `${i * 0.07}s` }}>
              <ActivityCard activity={activity} />
            </div>
          ))
        )}
      </div>

      {/* Post button */}
      <button className="fixed bottom-24 right-4 lg:bottom-8 lg:right-8 w-14 h-14 bg-pace-ink text-pace-accent rounded-2xl flex items-center justify-center shadow-lg hover:scale-105 transition-transform z-40">
        <Plus size={24} />
      </button>
    </div>
  )
}

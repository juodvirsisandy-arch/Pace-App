'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ChevronRight, ChevronLeft, Check } from 'lucide-react'
import { Sport, SPORT_EMOJIS, SPORT_COLORS, SPORT_LABELS } from '@/types'

const SPORTS: Sport[] = ['run', 'bike', 'swim', 'triathlon', 'ultra']

const GOALS = [
  { id: 'finish',   label: 'Finish my first race' },
  { id: 'pr',       label: 'Set a personal record' },
  { id: 'kona',     label: 'Qualify for Kona / Worlds' },
  { id: 'connect',  label: 'Connect with athletes' },
  { id: 'training', label: 'Find training partners' },
  { id: 'explore',  label: 'Discover new events' },
]

const LEVELS = [
  { id: 'beginner',     label: 'Beginner',     sub: 'Just getting started' },
  { id: 'intermediate', label: 'Intermediate', sub: '1–3 years of racing' },
  { id: 'advanced',     label: 'Advanced',     sub: '3+ years, regular racing' },
  { id: 'elite',        label: 'Elite',        sub: 'Podium contender' },
]

type Step = 'welcome' | 'sports' | 'level' | 'goals' | 'profile' | 'done'
const STEPS: Step[] = ['welcome', 'sports', 'level', 'goals', 'profile', 'done']

export default function OnboardingPage() {
  const router = useRouter()
  const [step, setStep] = useState<Step>('welcome')
  const [selectedSports, setSelectedSports] = useState<Sport[]>([])
  const [selectedLevel, setSelectedLevel] = useState('')
  const [selectedGoals, setSelectedGoals] = useState<string[]>([])
  const [name, setName] = useState('')
  const [username, setUsername] = useState('')
  const [location, setLocation] = useState('')

  const stepIndex = STEPS.indexOf(step)
  const progress = (stepIndex / (STEPS.length - 1)) * 100

  function next() {
    const next = STEPS[stepIndex + 1]
    if (next) setStep(next)
  }
  function back() {
    const prev = STEPS[stepIndex - 1]
    if (prev) setStep(prev)
  }

  function toggleSport(s: Sport) {
    setSelectedSports(prev =>
      prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]
    )
  }
  function toggleGoal(g: string) {
    setSelectedGoals(prev =>
      prev.includes(g) ? prev.filter(x => x !== g) : [...prev, g]
    )
  }

  return (
    <div className="min-h-screen bg-pace-bg flex flex-col">
      {/* Progress bar */}
      {step !== 'welcome' && step !== 'done' && (
        <div className="h-1 bg-pace-border">
          <div
            className="h-full bg-pace-ink transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      <div className="flex-1 flex flex-col items-center justify-center px-6 py-10 max-w-lg mx-auto w-full">

        {/* WELCOME */}
        {step === 'welcome' && (
          <div className="text-center animate-fade-up">
            <div className="font-display font-black text-7xl tracking-wide mb-2">
              <span className="bg-pace-ink text-pace-accent px-3 py-1 rounded-xl">PACE</span>
            </div>
            <p className="font-mono-pace text-sm text-pace-ink3 tracking-widest uppercase mt-4 mb-2">
              Athlete Social Network
            </p>
            <p className="text-pace-ink2 text-base leading-relaxed mt-6 mb-10 max-w-xs mx-auto">
              Connect with triathletes, runners, cyclists and swimmers across the world.
            </p>
            <div className="flex flex-col gap-3">
              <button
                onClick={next}
                className="w-full py-4 bg-pace-ink text-pace-accent font-display font-bold text-xl tracking-wide rounded-2xl hover:opacity-90 transition-opacity active:scale-95"
              >
                Get started
              </button>
              <button className="w-full py-4 border border-pace-border rounded-2xl font-semibold text-pace-ink2 hover:bg-pace-surface2 transition-colors">
                Sign in
              </button>
            </div>
            <p className="font-mono-pace text-xs text-pace-ink3 mt-6">
              Join 12,400+ athletes worldwide
            </p>
          </div>
        )}

        {/* SPORTS */}
        {step === 'sports' && (
          <div className="w-full animate-fade-up">
            <div className="mb-8">
              <h2 className="font-display font-black text-4xl text-pace-ink tracking-wide">YOUR SPORTS</h2>
              <p className="text-pace-ink3 mt-2 text-sm">Pick all that apply — we'll personalise your feed.</p>
            </div>
            <div className="grid grid-cols-1 gap-3">
              {SPORTS.map(sport => {
                const selected = selectedSports.includes(sport)
                const color = SPORT_COLORS[sport]
                return (
                  <button
                    key={sport}
                    onClick={() => toggleSport(sport)}
                    className={`flex items-center gap-4 p-4 rounded-2xl border-2 transition-all text-left ${
                      selected ? 'border-pace-ink bg-pace-ink' : 'border-pace-border bg-pace-surface hover:border-pace-ink3'
                    }`}
                  >
                    <span className="text-3xl">{SPORT_EMOJIS[sport]}</span>
                    <span className={`font-display font-bold text-2xl tracking-wide ${selected ? 'text-pace-accent' : 'text-pace-ink'}`}>
                      {SPORT_LABELS[sport].toUpperCase()}
                    </span>
                    {selected && (
                      <div className="ml-auto w-6 h-6 rounded-full bg-pace-accent flex items-center justify-center">
                        <Check size={14} className="text-pace-ink" strokeWidth={3} />
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {/* LEVEL */}
        {step === 'level' && (
          <div className="w-full animate-fade-up">
            <div className="mb-8">
              <h2 className="font-display font-black text-4xl text-pace-ink tracking-wide">YOUR LEVEL</h2>
              <p className="text-pace-ink3 mt-2 text-sm">Help us match you with the right community.</p>
            </div>
            <div className="flex flex-col gap-3">
              {LEVELS.map(l => {
                const selected = selectedLevel === l.id
                return (
                  <button
                    key={l.id}
                    onClick={() => setSelectedLevel(l.id)}
                    className={`flex items-center gap-4 p-4 rounded-2xl border-2 transition-all text-left ${
                      selected ? 'border-pace-ink bg-pace-ink' : 'border-pace-border bg-pace-surface hover:border-pace-ink3'
                    }`}
                  >
                    <div className="flex-1">
                      <div className={`font-display font-bold text-xl tracking-wide ${selected ? 'text-pace-accent' : 'text-pace-ink'}`}>
                        {l.label.toUpperCase()}
                      </div>
                      <div className={`font-mono-pace text-xs mt-0.5 ${selected ? 'text-white/50' : 'text-pace-ink3'}`}>
                        {l.sub}
                      </div>
                    </div>
                    {selected && (
                      <div className="w-6 h-6 rounded-full bg-pace-accent flex items-center justify-center flex-shrink-0">
                        <Check size={14} className="text-pace-ink" strokeWidth={3} />
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {/* GOALS */}
        {step === 'goals' && (
          <div className="w-full animate-fade-up">
            <div className="mb-8">
              <h2 className="font-display font-black text-4xl text-pace-ink tracking-wide">YOUR GOALS</h2>
              <p className="text-pace-ink3 mt-2 text-sm">Select everything you're aiming for.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {GOALS.map(g => {
                const selected = selectedGoals.includes(g.id)
                return (
                  <button
                    key={g.id}
                    onClick={() => toggleGoal(g.id)}
                    className={`p-4 rounded-2xl border-2 transition-all text-left ${
                      selected ? 'border-pace-ink bg-pace-ink' : 'border-pace-border bg-pace-surface hover:border-pace-ink3'
                    }`}
                  >
                    <div className={`font-semibold text-sm leading-snug ${selected ? 'text-pace-accent' : 'text-pace-ink'}`}>
                      {g.label}
                    </div>
                    {selected && (
                      <div className="mt-2 w-5 h-5 rounded-full bg-pace-accent flex items-center justify-center">
                        <Check size={12} className="text-pace-ink" strokeWidth={3} />
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {/* PROFILE */}
        {step === 'profile' && (
          <div className="w-full animate-fade-up">
            <div className="mb-8">
              <h2 className="font-display font-black text-4xl text-pace-ink tracking-wide">YOUR PROFILE</h2>
              <p className="text-pace-ink3 mt-2 text-sm">Let other athletes find and recognise you.</p>
            </div>
            <div className="flex flex-col gap-4">
              <div>
                <label className="font-mono-pace text-xs text-pace-ink3 uppercase tracking-wider block mb-2">Full name</label>
                <input
                  type="text" value={name} onChange={e => setName(e.target.value)}
                  placeholder="e.g. Anna Vestergaard"
                  className="w-full px-4 py-3.5 rounded-xl border border-pace-border bg-pace-surface text-pace-ink placeholder:text-pace-ink3 focus:outline-none focus:border-pace-ink transition-colors"
                />
              </div>
              <div>
                <label className="font-mono-pace text-xs text-pace-ink3 uppercase tracking-wider block mb-2">Username</label>
                <div className="flex items-center border border-pace-border bg-pace-surface rounded-xl focus-within:border-pace-ink transition-colors overflow-hidden">
                  <span className="px-4 py-3.5 text-pace-ink3 border-r border-pace-border font-mono-pace text-sm">@</span>
                  <input
                    type="text" value={username} onChange={e => setUsername(e.target.value.toLowerCase().replace(/\s/g,''))}
                    placeholder="anna_tri"
                    className="flex-1 px-4 py-3.5 bg-transparent text-pace-ink placeholder:text-pace-ink3 focus:outline-none font-mono-pace text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="font-mono-pace text-xs text-pace-ink3 uppercase tracking-wider block mb-2">Location</label>
                <input
                  type="text" value={location} onChange={e => setLocation(e.target.value)}
                  placeholder="e.g. Vilnius, LT"
                  className="w-full px-4 py-3.5 rounded-xl border border-pace-border bg-pace-surface text-pace-ink placeholder:text-pace-ink3 focus:outline-none focus:border-pace-ink transition-colors"
                />
              </div>
            </div>
          </div>
        )}

        {/* DONE */}
        {step === 'done' && (
          <div className="text-center animate-fade-up">
            <div className="w-24 h-24 bg-pace-accent rounded-3xl flex items-center justify-center mx-auto mb-6">
              <Check size={48} className="text-pace-ink" strokeWidth={2.5} />
            </div>
            <h2 className="font-display font-black text-5xl text-pace-ink tracking-wide">YOU'RE IN!</h2>
            <p className="text-pace-ink2 mt-3 mb-10 text-sm leading-relaxed">
              Welcome to PACE, {name || 'athlete'}. Your community is waiting.
            </p>
            <button
              onClick={() => router.push('/feed')}
              className="w-full py-4 bg-pace-ink text-pace-accent font-display font-bold text-xl tracking-wide rounded-2xl hover:opacity-90 transition-opacity"
            >
              Go to feed →
            </button>
          </div>
        )}

        {/* Navigation buttons */}
        {step !== 'welcome' && step !== 'done' && (
          <div className="flex gap-3 mt-8 w-full">
            <button
              onClick={back}
              className="flex items-center gap-2 px-5 py-3.5 rounded-xl border border-pace-border text-pace-ink2 hover:bg-pace-surface2 transition-colors font-semibold"
            >
              <ChevronLeft size={18} /> Back
            </button>
            <button
              onClick={next}
              disabled={
                (step === 'sports' && selectedSports.length === 0) ||
                (step === 'level'  && !selectedLevel) ||
                (step === 'goals'  && selectedGoals.length === 0) ||
                (step === 'profile' && (!name || !username))
              }
              className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl bg-pace-ink text-pace-accent font-display font-bold text-lg tracking-wide hover:opacity-90 transition-opacity disabled:opacity-30 disabled:cursor-not-allowed"
            >
              {step === 'profile' ? 'Create profile' : 'Continue'} <ChevronRight size={20} />
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

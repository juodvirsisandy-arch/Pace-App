# PACE — Athlete Social Network

A social platform for triathletes, runners, cyclists and swimmers.

## Stack
- **Next.js 14** (App Router)
- **Tailwind CSS** with custom PACE design tokens
- **Supabase** (auth, database, realtime)
- **TypeScript** throughout

## Quick start

### 1. Install dependencies
```bash
npm install
```

### 2. Set up Supabase
1. Go to [supabase.com](https://supabase.com) and create a free project
2. In the SQL editor, paste and run `supabase-schema.sql`
3. Copy your project URL and anon key from Settings → API

### 3. Configure environment
```bash
cp .env.local.example .env.local
# Fill in your Supabase URL and anon key
```

### 4. Run the dev server
```bash
npm run dev
# Open http://localhost:3000
```

The app runs fully with mock data — no Supabase needed for the UI.

## Project structure
```
src/
├── app/
│   ├── (app)/            # Authenticated pages (sidebar layout)
│   │   ├── feed/         # Activity feed
│   │   ├── nearby/       # Find athletes nearby
│   │   ├── events/       # Race board
│   │   └── profile/      # User profile & stats
│   ├── onboarding/       # Multi-step onboarding
│   └── auth/             # Login / signup (coming soon)
├── components/
│   ├── ui/               # SportBadge, Avatar, StatChip
│   ├── feed/             # ActivityCard, StoriesRow
│   └── layout/           # Sidebar, BottomNav
├── lib/
│   ├── supabase/         # Client + server Supabase clients
│   └── mock-data.ts      # Dev data (no backend needed)
├── types/                # TypeScript types + helpers
└── styles/               # Global CSS + fonts
```

## Roadmap
- [ ] Auth (Supabase email + Google)
- [ ] Strava OAuth integration
- [ ] Real Mapbox athlete map
- [ ] Activity creation / upload
- [ ] Push notifications
- [ ] Direct messaging
- [ ] Mobile app (React Native)

## Design system
- **Font**: Barlow Condensed (display) + DM Sans (body) + DM Mono (data)
- **Colors**: Near-black ink `#0F0F0E` + electric yellow accent `#E8FF47`
- **Sport colors**: Run `#FF6B35` · Bike `#3B82F6` · Swim `#06B6D4` · Tri `#8B5CF6`

'use client'
import { Plus } from 'lucide-react'
import { Profile, SPORT_COLORS } from '@/types'
import { Avatar } from '@/components/ui/Avatar'

interface StoriesRowProps {
  athletes: Profile[]
}

export function StoriesRow({ athletes }: StoriesRowProps) {
  return (
    <div className="flex gap-4 px-4 pb-4 overflow-x-auto scrollbar-none" style={{ scrollbarWidth: 'none' }}>
      {/* Add story */}
      <div className="flex flex-col items-center gap-1.5 flex-shrink-0 cursor-pointer">
        <div className="w-14 h-14 rounded-full border-2 border-dashed border-pace-border flex items-center justify-center text-pace-ink3 hover:border-pace-ink3 transition-colors">
          <Plus size={20} />
        </div>
        <span className="font-mono-pace text-[10px] text-pace-ink3">You</span>
      </div>

      {athletes.map(athlete => {
        const primarySport = athlete.sports[0]
        const ringColor = primarySport ? SPORT_COLORS[primarySport] : '#0F0F0E'
        return (
          <div key={athlete.id} className="flex flex-col items-center gap-1.5 flex-shrink-0 cursor-pointer group">
            <div
              className="w-14 h-14 rounded-full p-0.5 transition-transform group-hover:scale-105"
              style={{ background: ringColor }}
            >
              <div className="w-full h-full rounded-full bg-pace-bg p-0.5">
                <Avatar name={athlete.full_name} src={athlete.avatar_url} size={48} className="!w-full !h-full" />
              </div>
            </div>
            <span className="font-mono-pace text-[10px] text-pace-ink2 max-w-[56px] truncate text-center">
              {athlete.username}
            </span>
          </div>
        )
      })}
    </div>
  )
}

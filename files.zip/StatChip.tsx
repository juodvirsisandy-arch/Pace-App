interface StatChipProps {
  value: string
  label: string
  unit?: string
}

export function StatChip({ value, label, unit }: StatChipProps) {
  return (
    <div className="flex flex-col">
      <div className="font-display font-bold text-2xl text-pace-ink leading-none">
        {value}
        {unit && <span className="text-sm font-normal ml-0.5">{unit}</span>}
      </div>
      <div className="font-mono-pace text-[10px] text-pace-ink3 uppercase tracking-wider mt-0.5">
        {label}
      </div>
    </div>
  )
}

'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, MapPin, Calendar, User, Zap, Settings, Bell } from 'lucide-react'
import { Avatar } from '@/components/ui/Avatar'
import { MY_PROFILE } from '@/lib/mock-data'

const NAV_ITEMS = [
  { href: '/feed',    icon: Home,     label: 'Feed' },
  { href: '/nearby',  icon: MapPin,   label: 'Nearby' },
  { href: '/events',  icon: Calendar, label: 'Events' },
  { href: '/profile', icon: User,     label: 'Profile' },
]

export function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-pace-ink flex flex-col z-50 hidden lg:flex">
      {/* Logo */}
      <div className="px-6 py-7">
        <div className="font-display font-black text-4xl tracking-wide">
          <span className="bg-pace-accent text-pace-ink px-1.5 py-0.5 rounded">PACE</span>
        </div>
        <div className="font-mono-pace text-[10px] text-white/30 mt-1 tracking-widest uppercase">
          Athlete Social
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3">
        {NAV_ITEMS.map(({ href, icon: Icon, label }) => {
          const active = pathname.startsWith(href)
          return (
            <Link
              key={href} href={href}
              className={`flex items-center gap-3 px-3 py-3 rounded-xl mb-1 transition-all group ${
                active
                  ? 'bg-white/10 text-white'
                  : 'text-white/50 hover:text-white/80 hover:bg-white/5'
              }`}
            >
              <Icon size={20} strokeWidth={active ? 2 : 1.5} />
              <span className={`font-body text-sm ${active ? 'font-semibold' : 'font-normal'}`}>
                {label}
              </span>
              {active && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-pace-accent" />}
            </Link>
          )
        })}
      </nav>

      {/* Bottom */}
      <div className="px-3 pb-6 border-t border-white/10 pt-4">
        <Link href="/profile" className="flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-white/5 transition-colors">
          <Avatar name={MY_PROFILE.full_name} size={36} />
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-white truncate">{MY_PROFILE.full_name}</div>
            <div className="font-mono-pace text-[10px] text-white/40 truncate">@{MY_PROFILE.username}</div>
          </div>
          <Settings size={16} className="text-white/30 hover:text-white/60 transition-colors" />
        </Link>
      </div>
    </aside>
  )
}

// Mobile bottom nav
export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-pace-border lg:hidden z-50">
      <div className="flex">
        {NAV_ITEMS.map(({ href, icon: Icon, label }) => {
          const active = pathname.startsWith(href)
          return (
            <Link
              key={href} href={href}
              className={`flex-1 flex flex-col items-center gap-1 py-3 transition-colors ${
                active ? 'text-pace-ink' : 'text-pace-ink3'
              }`}
            >
              <Icon size={22} strokeWidth={active ? 2 : 1.5} />
              <span className="font-mono-pace text-[10px]">{label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}

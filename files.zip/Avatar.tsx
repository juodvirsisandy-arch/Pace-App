'use client'
import Image from 'next/image'
import { SPORT_COLORS } from '@/types'

const GRADIENTS = [
  ['#8B5CF6','#a78bfa'], ['#FF6B35','#ff9a35'], ['#06B6D4','#22d3ee'],
  ['#3B82F6','#60a5fa'], ['#e04040','#ff7070'], ['#22c55e','#4ade80'],
]

function getGradient(name: string) {
  const i = name.charCodeAt(0) % GRADIENTS.length
  return GRADIENTS[i]
}

interface AvatarProps {
  name: string
  src?: string
  size?: number
  className?: string
}

export function Avatar({ name, src, size = 40, className = '' }: AvatarProps) {
  const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
  const [from, to] = getGradient(name)

  if (src) {
    return (
      <Image
        src={src} alt={name} width={size} height={size}
        className={`rounded-full object-cover ${className}`}
        style={{ width: size, height: size }}
      />
    )
  }

  return (
    <div
      className={`rounded-full flex items-center justify-center font-display font-black text-white flex-shrink-0 ${className}`}
      style={{
        width: size, height: size,
        background: `linear-gradient(135deg, ${from}, ${to})`,
        fontSize: Math.round(size * 0.35),
      }}
    >
      {initials}
    </div>
  )
}
